const canvas = document.getElementById("GameCanvas");
const context = canvas.getContext("2d");

const canvasSize = 400;
canvas.width = canvasSize;
canvas.height = canvasSize;

let brush = { x: 200, y: 200};
let drawing = false;
const boxSize = 20; 
let time = 20;

context.lineWidth = 4;
context.fillStyle = "pink";  
context.strokeStyle = "black"; 

function getMousePos(event, canvas) {
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    return { x, y };
}

function startDrawing(event) {
    if (time > 0) {
        drawing = true;
        const mousePos = getMousePos(event, canvas);
        brush.x = Math.floor(mousePos.x / boxSize) * boxSize;
        brush.y = Math.floor(mousePos.y / boxSize) * boxSize; 
    }
}

function draw() {
    if (drawing = false ) return;
    // brush position
    context.fillRect(brush.x, brush.y, boxSize, boxSize);
    context.strokeRect(brush.x, brush.y, boxSize, boxSize);
}

function stopDrawing() {
    drawing = false;
}

function startGame() {
    gameInterval = setInterval("GameCanvas", 1000);
}

// Event listeners
canvas.addEventListener('mousedown', startDrawing);
canvas.addEventListener('mousemove', draw);
canvas.addEventListener('mouseup', stopDrawing);
canvas.addEventListener('mouseout', stopDrawing);

